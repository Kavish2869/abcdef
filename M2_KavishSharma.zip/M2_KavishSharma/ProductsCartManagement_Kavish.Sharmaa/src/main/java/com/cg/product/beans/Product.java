package com.cg.product.beans;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Product {

	@Id
	private String productId;
	private String productName,productModel;
	private long productPrice;
	
	public Product() {}
	
	public Product(String productName, String productModel, long productPrice) {
		super();
		this.productName = productName;
		this.productModel = productModel;
		this.productPrice = productPrice;
	}
	
	public Product(String productId, String productName, String productModel, long productPrice) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.productModel = productModel;
		this.productPrice = productPrice;
	}
	
	@Override
	public String toString() {
		return "Product [productId=" + productId + ", productName=" + productName + ", productModel=" + productModel
				+ ", productPrice=" + productPrice + "]";
	}
	
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getProductModel() {
		return productModel;
	}
	public void setProductModel(String productModel) {
		this.productModel = productModel;
	}
	public long getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(long productPrice) {
		this.productPrice = productPrice;
	}	
}