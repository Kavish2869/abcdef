package com.cg.product.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.product.beans.Product;
import com.cg.product.exceptions.ProductNotFoundException;
import com.cg.product.services.IProductService;

@Controller
public class ProductController {

	@Autowired
	IProductService productService;

	@RequestMapping(value= {"/acceptProductDetails"},method=RequestMethod.POST,produces=MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public ResponseEntity<String> acceptProductDetails(@ModelAttribute Product product){
		product = productService.acceptProductDetails(product);
		return new ResponseEntity<>("Product details successfully added and Product ID is "+product.getProductId(),HttpStatus.OK);
	}

	@RequestMapping(value= {"/updateProductDetails"},method=RequestMethod.PUT,produces=MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public ResponseEntity<String> updateProductDetails(@ModelAttribute Product product) throws ProductNotFoundException{
		product = productService.update(product);
		return new ResponseEntity<>("Product details successfully updated and Product ID is "+product.getProductId(),HttpStatus.OK);
	}

	@RequestMapping(value="/removeProductDetails",method=RequestMethod.DELETE)
	public ResponseEntity<String> removeMovieDetails(@RequestParam String productId) throws ProductNotFoundException{
		productService.removeProductDetails(productId);
		return new ResponseEntity<>("Product removed successfully",HttpStatus.OK);
	}

	@RequestMapping(value= {"/getAllProductDetails"},method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE,
			headers="Accept=application/json")
	public ResponseEntity<List<Product>> getAllProductDetailsPathParam(){
		return new ResponseEntity<List<Product>>(productService.getAllProductDetails(),HttpStatus.OK);
	}

	@RequestMapping(value= {"/getProductDetails"},method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE,
			headers="Accept=application/json")
	public ResponseEntity<Product> getProductDetailRequestPathParam(@RequestParam String productId) throws ProductNotFoundException
	{
		Product product = productService.getProductDetail(productId);
		return new ResponseEntity<Product>(product,HttpStatus.OK);
	}
}