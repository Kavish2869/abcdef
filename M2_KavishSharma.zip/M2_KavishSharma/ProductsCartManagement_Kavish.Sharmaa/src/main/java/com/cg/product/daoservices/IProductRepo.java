package com.cg.product.daoservices;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.cg.product.beans.Product;

public interface IProductRepo extends JpaRepository<Product, Integer> {
	@Query(value="from Product p ")	//Query for displaying all product details from database
	List<Product> getAllProductDetails();
	@Query(value="from Product p where p.productId = :productId")
	Product findOne(String productId); 
}