package com.cg.product.services;

import java.util.List;

import com.cg.product.beans.Product;
import com.cg.product.exceptions.ProductNotFoundException;

public interface IProductService {
	
	Product acceptProductDetails(Product product);	//Create Product
	
	public Product update(Product product) throws ProductNotFoundException;		//Update Product
	
	boolean removeProductDetails(String productId) throws ProductNotFoundException;	//Delete Product
	
	List<Product> getAllProductDetails();	//List all products
	
	Product getProductDetail(String productId) throws ProductNotFoundException;	//Find product object
}