package com.cg.product.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.product.beans.Product;
import com.cg.product.daoservices.IProductRepo;
import com.cg.product.exceptions.ProductNotFoundException;
@Component("iProductService")
public class ProductServiceImpl implements IProductService{

	@Autowired	//Implementation of IProductRepo Interface
	private IProductRepo productDAO;
	
	@Override
	public Product acceptProductDetails(Product product) {
		return productDAO.save(product);
	}

	@SuppressWarnings("null")
	@Override
	public Product update(Product product) throws ProductNotFoundException {
		product=productDAO.findOne(product.getProductId());
		if(product==null)
			throw new ProductNotFoundException("Product Not found for "+product.getProductId());
		product.setProductId(product.getProductId());
		product.setProductModel(product.getProductModel());
		product.setProductName(product.getProductName());
		product.setProductPrice(product.getProductPrice());
		return productDAO.save(product);
		 
	}

	@Override
	public boolean removeProductDetails(String productId) throws ProductNotFoundException {
		Product product=productDAO.findOne(productId);
		if(product==null)
			throw new ProductNotFoundException("Product Not found for "+productId);
		productDAO.delete(getProductDetail(productId));
		return true;
	}

	@Override
	public List<Product> getAllProductDetails() {
		return productDAO.findAll();
	}

	@Override
	public Product getProductDetail(String productId) throws ProductNotFoundException {
		Product product=productDAO.findOne(productId);
		if(product==null)
			throw new ProductNotFoundException("Product Not found for "+productId);
		return productDAO.findOne(productId);
	}

}